//============================================================
//= Hercules Cache Folder Readme File
//===== By: ==================================================
//= Hercules Dev Team
//============================================================

Don't touch these folders or files inside of them!
They are read and written by the server during runtime when it feels it is wise.
